/**
 * Contains stories for filling class info into an object
 * Created by tedonema on 14/06/2015.
 */
package uk.co.jemos.podam.test.unit.features.classInfo;