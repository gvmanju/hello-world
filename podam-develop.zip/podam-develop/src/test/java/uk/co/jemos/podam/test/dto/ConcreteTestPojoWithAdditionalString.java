/**
 *
 */
package uk.co.jemos.podam.test.dto;

public class ConcreteTestPojoWithAdditionalString extends AbstractTestPojo {

}
