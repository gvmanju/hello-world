/**
 * 
 */
package uk.co.jemos.podam.test.enums;

/**
 * An enum to use in tests
 * 
 * @author mtedone
 * 
 */
public enum ExternalRatePodamEnum {

	EXTERNAL_COOL, EXTERNAL_ROCKS, EXTERNAL_SUPERCOOL

}
